var svgns = "http://www.w3.org/2000/svg";
var cajaSVG = document.getElementById('svg');
var cx = 20;
var cy = 20;
var r = 19;

var nReservas = document.getElementById('nReservas').value;
var buttonRefresco = document.getElementById('refrescar');
var reservasAsignadas = 0;
buttonRefresco.addEventListener("click", function() {
    nReservas = document.getElementById('nReservas').value;
    console.log(nReservas);
});
for (var x = 50; x < 250; x += 50) {
    for (var y = 50; y < 250; y += 50) {
        var circle = document.createElementNS(svgns, 'circle');
        circle.setAttributeNS(null, 'cx', x);
        circle.setAttributeNS(null, 'cy', y);
        circle.setAttributeNS(null, 'r', r);
        circle.classList.add("noAsignado");

        pintarAsignados(x,y);
        if (circle.classList.contains("noAsignado") || circle.classList.contains("Asignado")) {

            circle.addEventListener("click", cambiarAsignado);


        }
        cajaSVG.appendChild(circle);
    }
}

function cambiarAsignado(e) {

        if (nReservas !== "" &&
            reservasAsignadas < nReservas &&
            this.classList.contains("noAsignado")) {
            this.classList.remove("noAsignado");
            this.classList.add("Asignado");
            reservasAsignadas++;

    } else if (this.classList.contains("Asignado")) {
        this.classList.add("noAsignado");
        this.classList.remove("Asignado");
        reservasAsignadas--;
    }


}

function pintarAsignados(x,y) {
  if (x == 50 && y == 50) {
      circle.classList.remove("noAsignado");
      circle.classList.add("reserva");
  }
  if (x == 100 && y == 50) {
      circle.classList.remove("noAsignado");
      circle.classList.add("reserva");
  }
  if (x ==100 && y == 100) {
      circle.classList.remove("noAsignado");
      circle.classList.add("reserva");
  }
  if (x == 150 && y == 150) {
      circle.classList.remove("noAsignado");
      circle.classList.add("reserva");
  }
}
